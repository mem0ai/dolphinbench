These results use Hermes with GPT-5.6-Luna at high reasoning effort and self-hosted Supermemory. The three persona run files identify the agent settings, source versions, inputs, and selected runs.

The total cost is $345.64: $63.86 for agent calls and $281.79 for memory processing. Totals are calculated before rounding and exclude grading and infrastructure.
