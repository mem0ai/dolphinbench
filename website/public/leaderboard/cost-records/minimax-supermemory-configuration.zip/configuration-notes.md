These results use Hermes with MiniMax M3 at high reasoning effort and self-hosted Supermemory. The three persona run files identify the agent settings, source versions, inputs, and selected runs.

The total cost is $497.70: $111.68 for agent calls and $386.02 for memory processing. Totals are calculated before rounding and exclude grading and infrastructure.
