These results use Hermes with GPT-5.6-Luna at high reasoning effort and Mem0. The three persona run files identify the agent settings, source versions, inputs, and selected runs.

The total cost is $96.21: $61.54 for agent calls and $34.68 for memory processing. Totals are calculated before rounding and exclude grading and infrastructure.
